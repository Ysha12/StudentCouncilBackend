import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-municipaldash',
  templateUrl: './municipaldash.component.html',
  styleUrls: ['./municipaldash.component.css']
})
export class MunicipaldashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
