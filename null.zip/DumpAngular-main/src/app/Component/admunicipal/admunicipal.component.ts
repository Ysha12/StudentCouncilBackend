import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admunicipal',
  templateUrl: './admunicipal.component.html',
  styleUrls: ['./admunicipal.component.css']
})
export class AdmunicipalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
