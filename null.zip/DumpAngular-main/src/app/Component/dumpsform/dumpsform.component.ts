import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dumpsform',
  templateUrl: './dumpsform.component.html',
  styleUrls: ['./dumpsform.component.css']
})
export class DumpsformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
