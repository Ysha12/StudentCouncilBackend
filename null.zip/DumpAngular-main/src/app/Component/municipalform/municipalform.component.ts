import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-municipalform',
  templateUrl: './municipalform.component.html',
  styleUrls: ['./municipalform.component.css']
})
export class MunicipalformComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
